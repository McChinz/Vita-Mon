// Wild Grass - simple creature-catching demo for PS Vita (VitaSDK + vita2d)
// Walk into the tall grass, a wild creature appears, throw a ball to catch it.
// All 22 creatures are original: pixel sprites are generated from a seed.

#include <psp2/ctrl.h>
#include <psp2/kernel/processmgr.h>
#include <vita2d.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#define SW 960
#define SH 544
#define NCRE 22
#define GW 12
#define GH 12

static const char *NAMES[NCRE] = {
    "Embrat",  "Pebblin", "Fluffor", "Zaptick", "Mossel",  "Drizzlet",
    "Gloomp",  "Cindrake","Wisplet", "Burrowl", "Thornip", "Quillby",
    "Snorbit", "Marblit", "Fizzard", "Glimmow", "Tuskle",  "Brambo",
    "Chillup", "Rumblet", "Sproutik","Nimbyte"};

static const unsigned int BODY[NCRE] = {
    RGBA8(230, 90, 50, 255),  RGBA8(150, 140, 130, 255), RGBA8(240, 200, 220, 255),
    RGBA8(240, 220, 60, 255), RGBA8(80, 160, 70, 255),   RGBA8(70, 140, 230, 255),
    RGBA8(110, 70, 150, 255), RGBA8(200, 50, 60, 255),   RGBA8(170, 220, 240, 255),
    RGBA8(150, 100, 60, 255), RGBA8(60, 130, 60, 255),   RGBA8(120, 90, 170, 255),
    RGBA8(100, 100, 120, 255),RGBA8(190, 190, 200, 255), RGBA8(240, 150, 40, 255),
    RGBA8(250, 230, 150, 255),RGBA8(210, 180, 140, 255), RGBA8(100, 160, 40, 255),
    RGBA8(140, 210, 230, 255),RGBA8(130, 90, 70, 255),   RGBA8(130, 200, 90, 255),
    RGBA8(80, 90, 200, 255)};

static const unsigned int ACC[NCRE] = {
    RGBA8(255, 210, 90, 255), RGBA8(200, 190, 170, 255), RGBA8(255, 255, 255, 255),
    RGBA8(120, 80, 30, 255),  RGBA8(200, 230, 120, 255), RGBA8(180, 230, 255, 255),
    RGBA8(210, 80, 160, 255), RGBA8(255, 150, 40, 255),  RGBA8(255, 255, 255, 255),
    RGBA8(230, 200, 150, 255),RGBA8(230, 80, 120, 255),  RGBA8(240, 220, 90, 255),
    RGBA8(200, 60, 60, 255),  RGBA8(90, 90, 110, 255),   RGBA8(250, 240, 120, 255),
    RGBA8(255, 140, 180, 255),RGBA8(255, 250, 230, 255), RGBA8(180, 60, 40, 255),
    RGBA8(255, 255, 255, 255),RGBA8(220, 120, 60, 255),  RGBA8(250, 220, 60, 255),
    RGBA8(120, 240, 230, 255)};

static unsigned char SPR[NCRE][GH][GW];
static unsigned int rng_state = 2463534242u;

static unsigned int rnd(void) {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return rng_state;
}

// cell values: 0 empty, 1 body, 2 accent, 3 eye white, 4 pupil, 5 outline
static void gen_sprite(int id) {
    rng_state = 0x9E3779B9u * (unsigned)(id + 7) + 1234567u;
    for (int i = 0; i < 5; i++) rnd();
    memset(SPR[id], 0, sizeof(SPR[id]));
    for (int r = 0; r < GH; r++) {
        for (int c = 0; c < GW / 2; c++) {
            int dx = 5 - c;
            int dy = abs(2 * r - 11);
            int filled = 0;
            if (dx <= 2 && r >= 3 && r <= 9) {
                filled = 1;
            } else {
                int p = 80 - 15 * dx - 2 * dy;
                if (id % 3 == 0 && r < 3 && dx >= 2 && dx <= 3) p += 45;   // ears
                if (id % 3 == 1 && r >= 4 && r <= 8 && dx >= 3) p += 40;   // arms/wings
                if (id % 3 == 2 && r >= 9 && dx >= 2) p += 40;             // feet/tail
                filled = ((int)(rnd() % 100) < p);
            }
            if (filled) {
                unsigned char v = 1;
                if (r >= 6 && r <= 9 && dx <= 1) v = 2;          // belly
                else if (rnd() % 100 < 12) v = 2;                 // speckles
                SPR[id][r][c] = v;
                SPR[id][r][GW - 1 - c] = v;
            }
        }
    }
    // eyes
    SPR[id][4][3] = 3; SPR[id][4][8] = 3;
    SPR[id][5][3] = 4; SPR[id][5][8] = 4;
    // outline
    unsigned char tmp[GH][GW];
    memcpy(tmp, SPR[id], sizeof(tmp));
    for (int r = 0; r < GH; r++)
        for (int c = 0; c < GW; c++) {
            if (tmp[r][c]) continue;
            int near = 0;
            if (r > 0 && tmp[r - 1][c]) near = 1;
            if (r < GH - 1 && tmp[r + 1][c]) near = 1;
            if (c > 0 && tmp[r][c - 1]) near = 1;
            if (c < GW - 1 && tmp[r][c + 1]) near = 1;
            if (near) SPR[id][r][c] = 5;
        }
}

static void draw_sprite(int id, float x, float y, float s) {
    for (int r = 0; r < GH; r++)
        for (int c = 0; c < GW; c++) {
            unsigned char v = SPR[id][r][c];
            if (!v) continue;
            unsigned int col;
            switch (v) {
                case 1: col = BODY[id]; break;
                case 2: col = ACC[id]; break;
                case 3: col = RGBA8(255, 255, 255, 255); break;
                case 4: col = RGBA8(10, 10, 20, 255); break;
                default: col = RGBA8(30, 30, 45, 255); break;
            }
            vita2d_draw_rectangle(x + c * s, y + r * s, s, s, col);
        }
}

static void draw_ball(float x, float y, float r) {
    vita2d_draw_fill_circle(x, y, r, RGBA8(220, 40, 40, 255));
    vita2d_draw_rectangle(x - r, y - 1.5f, r * 2, 3, RGBA8(20, 20, 20, 255));
    vita2d_draw_fill_circle(x, y, r * 0.35f, RGBA8(255, 255, 255, 255));
}

// ---------------------------------------------------------------- game state
enum { M_WORLD, M_FLASH, M_BATTLE };
enum { B_MSG, B_MENU, B_THROW, B_SHAKE };
enum { AFT_MENU, AFT_ENEMY, AFT_END };

static int mode = M_WORLD;
static float px = 480, py = 400;
static float stepAccum = 0;
static int flashT = 0;

static int bstate, afterMsg, bt;
static char msg[96];
static int menuSel;
static int enemyId, eLv, eHp, eMax;
static int pId = 0, pLv = 12, pHp, pMax = 40;
static int balls = 10;
static unsigned char caught[NCRE];
static int willCatch, shakes;

static const int GX = 8 * 32, GY = 4 * 32, GWID = 14 * 32, GHEI = 9 * 32;

static void set_msg(const char *s, int after) {
    snprintf(msg, sizeof(msg), "%s", s);
    afterMsg = after;
    bstate = B_MSG;
    bt = 0;
}

static void start_battle(void) {
    enemyId = rnd() % NCRE;
    eLv = 3 + rnd() % 6;
    eMax = 12 + eLv * 3;
    eHp = eMax;
    pHp = pMax;
    menuSel = 0;
    char b[96];
    snprintf(b, sizeof(b), "A wild %s appeared!", NAMES[enemyId]);
    set_msg(b, AFT_MENU);
    mode = M_BATTLE;
}

static void advance_msg(void) {
    if (afterMsg == AFT_MENU) {
        bstate = B_MENU;
    } else if (afterMsg == AFT_ENEMY) {
        int d = 2 + rnd() % 5;
        pHp -= d;
        if (pHp < 1) pHp = 1;  // demo: your creature never faints
        char b[96];
        snprintf(b, sizeof(b), "Wild %s attacked! (-%d)", NAMES[enemyId], d);
        set_msg(b, AFT_MENU);
    } else {
        mode = M_WORLD;
        stepAccum = 0;
    }
}

static void do_menu_choice(void) {
    char b[96];
    if (menuSel == 0) {  // FIGHT
        int d = 6 + rnd() % 7;
        eHp -= d;
        if (eHp <= 0) {
            eHp = 0;
            snprintf(b, sizeof(b), "Wild %s fainted!", NAMES[enemyId]);
            set_msg(b, AFT_END);
        } else {
            snprintf(b, sizeof(b), "%s attacked! (-%d)", NAMES[pId], d);
            set_msg(b, AFT_ENEMY);
        }
    } else if (menuSel == 1) {  // BALL
        if (balls <= 0) {
            set_msg("You're out of balls!", AFT_MENU);
            return;
        }
        balls--;
        int chance = 25 + 65 * (eMax - eHp) / eMax;
        willCatch = ((int)(rnd() % 100) < chance);
        shakes = willCatch ? 3 : (int)(rnd() % 3);
        bstate = B_THROW;
        bt = 0;
    } else {  // RUN
        set_msg("Got away safely!", AFT_END);
    }
}

static void draw_hpbar(float x, float y, float w, int hp, int max) {
    vita2d_draw_rectangle(x, y, w, 12, RGBA8(40, 40, 40, 255));
    float f = max ? (float)hp / max : 0;
    unsigned int col = f > 0.5f ? RGBA8(60, 200, 80, 255)
                     : f > 0.2f ? RGBA8(240, 200, 40, 255)
                                : RGBA8(220, 50, 50, 255);
    vita2d_draw_rectangle(x + 2, y + 2, (w - 4) * f, 8, col);
}

int main(void) {
    vita2d_init();
    vita2d_set_clear_color(RGBA8(0, 0, 0, 255));
    vita2d_pgf *pgf = vita2d_load_default_pgf();

    sceCtrlSetSamplingMode(SCE_CTRL_MODE_ANALOG);
    for (int i = 0; i < NCRE; i++) gen_sprite(i);
    rng_state = 88172645u ^ sceKernelGetProcessTimeLow();
    if (!rng_state) rng_state = 1;

    SceCtrlData pad;
    unsigned int oldBtn = 0;
    int frame = 0;

    while (1) {
        sceCtrlPeekBufferPositive(0, &pad, 1);
        unsigned int pressed = pad.buttons & ~oldBtn;
        oldBtn = pad.buttons;
        frame++;

        // ------------------------------------------------------------ update
        if (mode == M_WORLD) {
            float dx = 0, dy = 0;
            if (pad.buttons & SCE_CTRL_LEFT)  dx -= 1;
            if (pad.buttons & SCE_CTRL_RIGHT) dx += 1;
            if (pad.buttons & SCE_CTRL_UP)    dy -= 1;
            if (pad.buttons & SCE_CTRL_DOWN)  dy += 1;
            int lx = pad.lx - 128, ly = pad.ly - 128;
            if (abs(lx) > 30) dx = lx / 128.0f;
            if (abs(ly) > 30) dy = ly / 128.0f;
            float nx = px + dx * 3.0f, ny = py + dy * 3.0f;
            if (nx < 16) nx = 16;
            if (nx > SW - 16) nx = SW - 16;
            if (ny < 16) ny = 16;
            if (ny > SH - 16) ny = SH - 16;
            float moved = sqrtf((nx - px) * (nx - px) + (ny - py) * (ny - py));
            px = nx; py = ny;
            int inGrass = px > GX && px < GX + GWID && py > GY && py < GY + GHEI;
            if (inGrass && moved > 0) {
                stepAccum += moved;
                if (stepAccum >= 40) {
                    stepAccum = 0;
                    if (rnd() % 100 < 22) { mode = M_FLASH; flashT = 0; }
                }
            }
            if (pressed & SCE_CTRL_START) break;
        } else if (mode == M_FLASH) {
            if (++flashT > 36) start_battle();
        } else if (mode == M_BATTLE) {
            if (bstate == B_MSG) {
                bt++;
                if ((pressed & SCE_CTRL_CROSS) || bt > 100) advance_msg();
            } else if (bstate == B_MENU) {
                if (pressed & SCE_CTRL_UP)   menuSel = (menuSel + 2) % 3;
                if (pressed & SCE_CTRL_DOWN) menuSel = (menuSel + 1) % 3;
                if (pressed & SCE_CTRL_CROSS) do_menu_choice();
            } else if (bstate == B_THROW) {
                if (++bt >= 40) { bstate = B_SHAKE; bt = 0; }
            } else if (bstate == B_SHAKE) {
                bt++;
                if (bt >= 30 * shakes + 30) {
                    char b[96];
                    if (willCatch) {
                        caught[enemyId] = 1;
                        snprintf(b, sizeof(b), "Gotcha! %s was caught!", NAMES[enemyId]);
                        set_msg(b, AFT_END);
                    } else {
                        snprintf(b, sizeof(b), "Oh no! %s broke free!", NAMES[enemyId]);
                        set_msg(b, AFT_ENEMY);
                    }
                }
            }
        }

        // -------------------------------------------------------------- draw
        vita2d_start_drawing();
        vita2d_clear_screen();

        if (mode == M_WORLD || mode == M_FLASH) {
            vita2d_draw_rectangle(0, 0, SW, SH, RGBA8(120, 190, 90, 255));
            vita2d_draw_rectangle(GX, GY, GWID, GHEI, RGBA8(50, 140, 60, 255));
            for (int y = GY; y < GY + GHEI; y += 16)
                for (int x = GX + ((y / 16) % 2) * 8; x < GX + GWID; x += 16)
                    vita2d_draw_rectangle(x, y, 3, 8, RGBA8(30, 100, 40, 255));
            // player
            vita2d_draw_rectangle(px - 10, py - 4, 20, 22, RGBA8(40, 80, 200, 255));
            vita2d_draw_fill_circle(px, py - 12, 9, RGBA8(240, 200, 160, 255));
            vita2d_draw_rectangle(px - 9, py - 22, 18, 7, RGBA8(200, 40, 40, 255));
            int n = 0;
            for (int i = 0; i < NCRE; i++) n += caught[i];
            vita2d_pgf_draw_textf(pgf, 20, 34, RGBA8(255, 255, 255, 255), 1.2f,
                                  "Caught %d/%d   Balls %d", n, NCRE, balls);
            vita2d_pgf_draw_text(pgf, 20, 530, RGBA8(255, 255, 255, 255), 1.0f,
                                 "Walk into the tall grass!   START: quit");
            if (mode == M_FLASH) {
                int a = (flashT % 12 < 6) ? 220 : 0;
                vita2d_draw_rectangle(0, 0, SW, SH, RGBA8(255, 255, 255, a));
            }
        } else {
            // battle background
            vita2d_draw_rectangle(0, 0, SW, 260, RGBA8(110, 150, 220, 255));
            vita2d_draw_rectangle(0, 260, SW, SH - 260, RGBA8(190, 160, 120, 255));
            // platforms
            vita2d_draw_rectangle(560, 195, 280, 26, RGBA8(40, 140, 130, 255));
            vita2d_draw_rectangle(40, 370, 360, 30, RGBA8(40, 140, 130, 255));

            // enemy
            int hideEnemy = (bstate == B_SHAKE);
            if (!hideEnemy) draw_sprite(enemyId, 620, 62, 12);
            // player creature
            draw_sprite(pId, 120, 190, 16);

            // enemy box
            vita2d_draw_rectangle(40, 40, 340, 90, RGBA8(250, 250, 240, 255));
            vita2d_draw_rectangle(44, 44, 332, 82, RGBA8(70, 70, 80, 255));
            vita2d_pgf_draw_textf(pgf, 56, 74, RGBA8(255, 255, 255, 255), 1.3f, "%s", NAMES[enemyId]);
            vita2d_pgf_draw_textf(pgf, 290, 74, RGBA8(255, 255, 255, 255), 1.2f, "Lv%d", eLv);
            vita2d_pgf_draw_text(pgf, 56, 108, RGBA8(255, 220, 80, 255), 1.0f, "HP");
            draw_hpbar(90, 96, 270, eHp, eMax);

            // player box
            vita2d_draw_rectangle(560, 290, 360, 100, RGBA8(250, 250, 240, 255));
            vita2d_draw_rectangle(564, 294, 352, 92, RGBA8(70, 70, 80, 255));
            vita2d_pgf_draw_textf(pgf, 576, 326, RGBA8(255, 255, 255, 255), 1.3f, "%s", NAMES[pId]);
            vita2d_pgf_draw_textf(pgf, 810, 326, RGBA8(255, 255, 255, 255), 1.2f, "Lv%d", pLv);
            vita2d_pgf_draw_text(pgf, 576, 360, RGBA8(255, 220, 80, 255), 1.0f, "HP");
            draw_hpbar(610, 348, 280, pHp, pMax);
            vita2d_pgf_draw_textf(pgf, 780, 380, RGBA8(255, 255, 255, 255), 1.0f, "%d/%d", pHp, pMax);

            // ball animation
            if (bstate == B_THROW) {
                float p = bt / 40.0f;
                float bx = 190 + (692 - 190) * p;
                float by = 330 + (170 - 330) * p - 130 * sinf(3.14159f * p);
                draw_ball(bx, by, 14);
            } else if (bstate == B_SHAKE) {
                float off = ((bt % 30) < 18) ? 8 * sinf(bt * 0.7f) : 0;
                draw_ball(692 + off, 175, 14);
            }

            // text box
            vita2d_draw_rectangle(20, 415, 920, 115, RGBA8(250, 250, 240, 255));
            vita2d_draw_rectangle(26, 421, 908, 103, RGBA8(40, 40, 60, 255));
            if (bstate == B_MENU) {
                vita2d_pgf_draw_textf(pgf, 50, 480, RGBA8(255, 255, 255, 255), 1.4f,
                                      "What will %s do?", NAMES[pId]);
                vita2d_draw_rectangle(620, 421, 314, 103, RGBA8(230, 230, 220, 255));
                const char *opts[3] = {"FIGHT", "BALL", "RUN"};
                for (int i = 0; i < 3; i++) {
                    int y = 450 + i * 28;
                    if (i == menuSel)
                        vita2d_draw_fill_circle(645, y - 7, 6, RGBA8(200, 40, 40, 255));
                    if (i == 1)
                        vita2d_pgf_draw_textf(pgf, 665, y, RGBA8(20, 20, 30, 255), 1.1f, "BALL x%d", balls);
                    else
                        vita2d_pgf_draw_text(pgf, 665, y, RGBA8(20, 20, 30, 255), 1.1f, opts[i]);
                }
            } else {
                vita2d_pgf_draw_text(pgf, 50, 480, RGBA8(255, 255, 255, 255), 1.4f, msg);
                if (bstate == B_MSG && (frame / 20) % 2)
                    vita2d_draw_rectangle(900, 500, 14, 14, RGBA8(255, 255, 255, 255));
            }
        }

        vita2d_end_drawing();
        vita2d_swap_buffers();
    }

    vita2d_fini();
    vita2d_free_pgf(pgf);
    sceKernelExitProcess(0);
    return 0;
}
